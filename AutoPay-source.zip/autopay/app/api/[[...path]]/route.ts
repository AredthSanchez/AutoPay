import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '../../chatgpt-auth';
import {serve} from '../../../lib/autopay/service.mjs';
export const dynamic='force-dynamic';
async function handle(request:Request){return serve(request,{db:env.DB,bucket:env.BUCKET,user:await getChatGPTUser(),env});}
export const GET=handle;
export const POST=handle;
