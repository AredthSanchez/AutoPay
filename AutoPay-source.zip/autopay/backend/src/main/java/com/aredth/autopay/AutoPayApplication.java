package com.aredth.autopay;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class AutoPayApplication { public static void main(String[] args){SpringApplication.run(AutoPayApplication.class,args);} }
